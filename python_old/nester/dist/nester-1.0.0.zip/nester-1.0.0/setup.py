# -*- coding: utf-8 -*-
# @Author: nebulabhm760
# @Date:   2016-09-02 10:13:19
# @Last Modified by:   nebulabhm760
# @Last Modified time: 2016-09-02 10:16:33

from distutils.core import setup

setup(
    name = 'nester',
    version = '1.0.0',
    py_modules = ['nester'],
    author = 'nebulabhm',
    author_email = 'bhmg@sina.com',
    url = '',
    descripotion = 'A simple printer of nested lists',
    )


